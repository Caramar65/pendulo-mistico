# Astral Daily

Aplicación React + Vite + Tailwind lista para desplegar en Vercel.

## Ejecutar localmente

```bash
npm install
npm run dev
```

## Generar producción

```bash
npm run build
```

La carpeta `dist` generada por Vite es la salida de producción.

## Vercel

Importa este proyecto desde GitHub o sube la carpeta al flujo de despliegue de Vercel. Vercel detectará Vite automáticamente.
